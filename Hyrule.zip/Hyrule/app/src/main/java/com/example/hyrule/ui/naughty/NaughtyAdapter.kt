package com.example.hyrule.ui.naughty

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.hyrule.databinding.ListItemNaughtyBinding

class NaughtyAdapter : ListAdapter<String, NaughtyAdapter.NaughtyViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NaughtyViewHolder {
        val binding = ListItemNaughtyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NaughtyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NaughtyViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    class NaughtyViewHolder(private val binding: ListItemNaughtyBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(name: String) {
            binding.textNaughtyItem.text = name
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }
}
