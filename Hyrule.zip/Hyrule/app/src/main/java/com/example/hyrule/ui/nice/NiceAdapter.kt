// NiceAdapter.kt
package com.example.hyrule.ui.nice

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.hyrule.databinding.ListItemNiceBinding

class NiceAdapter : ListAdapter<String, NiceAdapter.NiceViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NiceViewHolder {
        val binding = ListItemNiceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NiceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NiceViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    class NiceViewHolder(private val binding: ListItemNiceBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(name: String) {
            binding.textNiceItem.text = name
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }
}
