package com.example.hyrule.ui.naughty

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QueryDocumentSnapshot

class NaughtyViewModel : ViewModel() {

    private val _text = MutableLiveData<List<String>>()
    val text: LiveData<List<String>> = _text
    private val db = FirebaseFirestore.getInstance()
    private val naughtyCollection = db.collection("naughty")

    init {
        // Fetch data from Firestore when ViewModel is created
        fetchDataFromFirestore()
    }

    fun addRandomName() {
        val namesArray = arrayOf("Alice", "Bob", "Charlie", "David", "Eva", "Frank")
        val randomIndex = (0 until namesArray.size).random()
        val randomName = namesArray[randomIndex]

        addNameToFirestore(randomName)
    }


    public fun addNameToFirestore(name: String) {
        val user = hashMapOf("Name" to name)
        naughtyCollection.add(user)
            .addOnSuccessListener { documentReference ->
                fetchDataFromFirestore() // Refresh data after adding
            }
            .addOnFailureListener { e ->
            }
    }

    private fun fetchDataFromFirestore() {
        naughtyCollection.get()
            .addOnSuccessListener { result ->
                val names = mutableListOf<String>()
                for (document in result) {
                    names.add(document.getString("Name") ?: "")
                }
                _text.value = names
            }
            .addOnFailureListener { e ->
            }
    }
}
