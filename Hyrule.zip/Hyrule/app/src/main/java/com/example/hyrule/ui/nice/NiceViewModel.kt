package com.example.hyrule.ui.nice

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore

class NiceViewModel : ViewModel() {

    private val _text = MutableLiveData<List<String>>()
    val text: LiveData<List<String>> = _text
    private val db = FirebaseFirestore.getInstance()
    private val niceCollection = db.collection("nice")

    init {
        fetchDataFromFirestore()
    }

    fun addRandomName() {
        val namesArray = arrayOf("Grace", "Henry", "Ivy", "Jack", "Karen", "Leo")
        val randomIndex = (0 until namesArray.size).random()
        val randomName = namesArray[randomIndex]

        addNameToFirestore(randomName)
    }

    public fun addNameToFirestore(name: String) {
        val user = hashMapOf("Name" to name)
        niceCollection.add(user)
            .addOnSuccessListener {
                fetchDataFromFirestore()
            }
            .addOnFailureListener {
            }
    }

    private fun fetchDataFromFirestore() {
        niceCollection.get()
            .addOnSuccessListener { result ->
                val names = mutableListOf<String>()
                for (document in result) {
                    names.add(document.getString("Name") ?: "")
                }
                _text.value = names
            }
            .addOnFailureListener {
                // Handle failure
            }
    }
}
