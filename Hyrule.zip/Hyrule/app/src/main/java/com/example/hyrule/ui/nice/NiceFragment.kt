package com.example.hyrule.ui.nice

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.hyrule.databinding.FragmentNiceBinding

class NiceFragment : Fragment() {
    private var _binding: FragmentNiceBinding? = null
    private val binding get() = _binding!!
    private lateinit var niceViewModel: NiceViewModel
    private lateinit var niceAdapter: NiceAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        niceViewModel = ViewModelProvider(this).get(NiceViewModel::class.java)
        _binding = FragmentNiceBinding.inflate(inflater, container, false)
        val root: View = binding.root

        recyclerView = binding.recyclerViewNice
        niceAdapter = NiceAdapter()
        recyclerView.adapter = niceAdapter

        val addButton: Button = binding.addButtonNice
        addButton.setOnClickListener {
            niceViewModel.addRandomName()
        }

        niceViewModel.text.observe(viewLifecycleOwner) {
            niceAdapter.submitList(it)
        }
        val nameEditText: EditText = binding.nameEditTextNice
        val submitButton: Button = binding.submitButtonNice

        submitButton.setOnClickListener {
            val enteredName = nameEditText.text.toString()
            if (enteredName.isNotEmpty()) {
                niceViewModel.addNameToFirestore(enteredName)
                nameEditText.text.clear()
            } else {
                Toast.makeText(requireContext(), "Please enter a name", Toast.LENGTH_SHORT).show()
            }
        }

        niceViewModel.text.observe(viewLifecycleOwner) {
            niceAdapter.submitList(it)
        }


        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
