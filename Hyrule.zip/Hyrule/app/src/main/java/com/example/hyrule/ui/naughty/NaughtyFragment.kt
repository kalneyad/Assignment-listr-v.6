package com.example.hyrule.ui.naughty

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.hyrule.databinding.FragmentNaughtyBinding

class NaughtyFragment : Fragment() {

    private var _binding: FragmentNaughtyBinding? = null
    private val binding get() = _binding!!
    private lateinit var naughtyViewModel: NaughtyViewModel
    private lateinit var naughtyAdapter: NaughtyAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        naughtyViewModel = ViewModelProvider(this).get(NaughtyViewModel::class.java)
        _binding = FragmentNaughtyBinding.inflate(inflater, container, false)
        val root: View = binding.root

        recyclerView = binding.recyclerViewNaughty
        naughtyAdapter = NaughtyAdapter()
        recyclerView.adapter = naughtyAdapter

        val addButton: Button = binding.addButton
        addButton.setOnClickListener {
            naughtyViewModel.addRandomName()
        }

        naughtyViewModel.text.observe(viewLifecycleOwner) {
            naughtyAdapter.submitList(it)
        }

        val nameEditText: EditText = binding.nameEditTextNaughty
        val submitButton: Button = binding.submitButtonNaughty

        submitButton.setOnClickListener {
            val enteredName = nameEditText.text.toString()
            if (enteredName.isNotEmpty()) {
                naughtyViewModel.addNameToFirestore(enteredName)
                nameEditText.text.clear()
            } else {
                Toast.makeText(requireContext(), "Please enter a name", Toast.LENGTH_SHORT).show()
            }
        }

        naughtyViewModel.text.observe(viewLifecycleOwner) {
            naughtyAdapter.submitList(it)
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
